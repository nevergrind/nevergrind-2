<?php
require_once 'session/start.php';
header('Content-Type: application/json');
$r = [];