<?php
require '../session/start.php';
echo '<pre>' . print_r($_SESSION, true) .'</pre>';