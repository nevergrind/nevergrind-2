<?php
$_SESSION['row'] = 0;
$_SESSION['name'] = '';