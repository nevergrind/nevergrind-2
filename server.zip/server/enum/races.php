<?php
	$races = [
		'Barbarian',
		'Dark Elf',
		'Dwarf',
		'Gnome',
		'Half Elf',
		'Halfling',
		'High Elf',
		'Human',
		'Orc',
		'Seraph',
		'Troll',
		'Wood Elf'
	];