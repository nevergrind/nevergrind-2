<?php
	$jobs = [
		'Bard', 
		'Cleric',
		'Druid',
		'Enchanter',
		'Templar',
		'Monk',
		'Warlock',
		'Crusader',
		'Ranger',
		'Rogue',
		'Shadow Knight',
		'Shaman',
		'Warrior',
		'Wizard'
	];