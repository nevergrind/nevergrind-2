<?php
require $_SERVER['DOCUMENT_ROOT'] . '/ng2/server/session/start.php';
require $_SERVER['DOCUMENT_ROOT'] . '/ng2/server/db.php';

// dragged item to same table to an empty slot
$stmt = $db->prepare('update `items` set data=? where row=?');
$stmt->bind_param('si', $_POST['data'], $_POST['itemRow']);
$stmt->execute();

$stmt = $db->prepare('delete from `items` where row=? and owner_id=?');
$stmt->bind_param('ii', $_POST['scrollRow'], $_SESSION['row']);
$stmt->execute();