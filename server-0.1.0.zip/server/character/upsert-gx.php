<?php
require $_SERVER['DOCUMENT_ROOT'] . '/ng2/server/session/start.php';
require $_SERVER['DOCUMENT_ROOT'] . '/ng2/server/db.php';

$stmt = $db->prepare('update `characters` set gold=gold+?, exp=exp+? where row=?');
$stmt->bind_param('iii', $_POST['gold'], $_POST['exp'], $_SESSION['row']);
$stmt->execute();