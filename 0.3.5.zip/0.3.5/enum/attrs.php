<?php
	$attrs = ['str', 'sta', 'agi', 'dex', 'wis', 'intel', 'cha'];