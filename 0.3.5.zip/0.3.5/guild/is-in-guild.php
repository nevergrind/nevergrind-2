<?php
if (!($_SESSION['guildName'])) {
	exit('You are not in a guild.');
}