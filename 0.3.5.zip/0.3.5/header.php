<?php
require_once 'session/alive.php';
header('Content-Type: application/json');
$r = [];