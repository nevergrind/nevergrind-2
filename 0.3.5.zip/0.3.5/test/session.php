<?php
require '../session/alive.php';
echo '<pre>' . print_r($_SESSION, true) .'</pre>';