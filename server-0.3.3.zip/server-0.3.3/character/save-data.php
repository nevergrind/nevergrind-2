<?php
require $_SERVER['DOCUMENT_ROOT'] . '/ng2/server/session/start.php';
require $_SERVER['DOCUMENT_ROOT'] . '/ng2/server/db.php';

$stmt = $db->prepare('update `characters` set data=? where row=?');
$stmt->bind_param('si', $_POST['data'], $_SESSION['row']);
$stmt->execute();