<?php
$_SESSION['guildId'] = 0;
$_SESSION['guildRank'] = 2;
$_SESSION['guildName'] = 0;